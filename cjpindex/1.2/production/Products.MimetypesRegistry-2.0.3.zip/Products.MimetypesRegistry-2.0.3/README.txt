Mimetypes Registry
==================

 * mimetypes_registry (the mimetypes tool) : handle mime types information


Authors
=======
Benjamin Saller <bcsaller@yahoo.com>
Sidnei da Silva  <sidnei@x3ng.com>
Sylvain Thenault <sylvain.thenault@logilab.fr>
Christian Heimes <tiran@cheimes.de>

Credits
=======
Icons from:

  * Plone: http://plone.org
  * Tango: http://tango.freedesktop.org
  * FamFamFam: http://http://www.famfamfam.com

