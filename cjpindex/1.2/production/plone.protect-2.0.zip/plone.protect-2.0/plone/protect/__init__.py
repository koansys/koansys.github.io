from plone.protect.utils import protect

from plone.protect.authenticator import check as CheckAuthenticator
from plone.protect.postonly import check as PostOnly
