Introduction
============

PloneBookmarklets is commonly used to bookmark content on popular sites like del.icio.us, digg, etc. These bookmarklets are typically used in blogs but can be used for bookmarking any kind of content.
