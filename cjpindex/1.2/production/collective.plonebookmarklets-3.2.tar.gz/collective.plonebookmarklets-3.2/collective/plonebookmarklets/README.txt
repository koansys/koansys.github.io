PloneBookmarklets Tool

This tool is used to manage bookmarklets, aka favlets, for social bookmarking sites.


What's New


Installation


Features

  * ZMI Interface to manage bookmarklets

  * 'Add Bookmarklet' document_action added for all Plone objects

  * Built using Zope annotations, with Zope 3 style and views

Requires

  * Plone 3.0.0 and greater

  * Zope 2.10.4 and greater

Written By

    David Ray <davidray@gmail.com>, Center for Open and Sustainable Learning <cosl.usu.edu> 
    Shane Graber <sgraber@gmail.com>


