five.customerize
================

Overview
--------

``five.customerize`` provides the ability to locally customize Page
Template-based browser views, much like it is possible to customize
file-system based view templates in the CMF's portal_skin tools.

Developer Resources
-------------------

- Subversion browser:

  http://svn.zope.org/five.customerize

- Read-only Subversion checkout:

  $ svn co http://svn.zope.org/repos/main/five.customerize/trunk

- Writable Subversion checkout:

  $ svn co svn+ssh://svn.zope.org/repos/main/five.customerize/trunk

