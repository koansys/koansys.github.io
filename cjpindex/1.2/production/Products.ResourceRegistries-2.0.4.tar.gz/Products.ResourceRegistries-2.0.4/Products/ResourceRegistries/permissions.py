from Products.CMFCore.permissions import View
from Products.CMFCore.permissions import ManagePortal
