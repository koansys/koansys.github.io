from registries import IResourceRegistry, ICSSRegistry, IKSSRegistry, IJSRegistry, ICookedFile
from viewletmanagers import IHtmlHeadScripts, IHtmlHeadStyles
