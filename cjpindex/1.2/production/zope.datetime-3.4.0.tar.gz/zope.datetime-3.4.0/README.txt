zope.datetime Package Readme
============================

Overview
--------

Commonly used date and time related utility functions.
