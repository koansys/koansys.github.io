from zope.interface import Interface


class IFileAttachment(Interface):
    pass


class IImageAttachment(Interface):
    pass
