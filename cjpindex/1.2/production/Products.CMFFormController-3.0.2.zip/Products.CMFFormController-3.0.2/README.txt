Overview
========

CMFFormController replaces the portal_form form validation mechanism from
Plone. It should work just fine in plain CMF as well.
