PROJECTNAME = "referencebrowserwidget"

WITH_SAMPLE_TYPES = False
