(See Products/CMFCore/README.txt).
