# This file has UNIX line endings (\n) on purpose
return 'unix'
