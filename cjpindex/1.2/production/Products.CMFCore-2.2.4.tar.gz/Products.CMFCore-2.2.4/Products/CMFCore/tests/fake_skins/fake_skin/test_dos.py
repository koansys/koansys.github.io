# This file has DOS line endings (\r\n) on purpose
return 'dos'
