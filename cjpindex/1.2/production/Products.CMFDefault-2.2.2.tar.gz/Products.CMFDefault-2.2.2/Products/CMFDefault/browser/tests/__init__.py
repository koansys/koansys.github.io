# Unit tests for CMFDefault browser views.
