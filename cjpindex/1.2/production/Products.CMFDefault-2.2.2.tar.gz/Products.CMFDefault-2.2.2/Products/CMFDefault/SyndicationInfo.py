from OFS.SimpleItem import SimpleItem

class SyndicationInformation(SimpleItem):
        id='syndication_information'
        meta_type='SyndicationInformation'
