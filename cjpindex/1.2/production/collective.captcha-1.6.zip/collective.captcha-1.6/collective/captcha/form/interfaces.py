from zope.schema.interfaces import IASCIILine

class ICaptcha(IASCIILine):
    u"""A field for captcha validation"""
