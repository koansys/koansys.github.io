# BBB
from Products.kupu.plone.interfaces import IPloneKupuLibraryTool

__all__ = (IPloneKupuLibraryTool, )
