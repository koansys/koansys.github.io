sitemap package
---------------

Contains the implementation for sitemap.xml.gz to hold a sitemap of all URLs
as the specs from:

    http://www.sitemaps.org/
