from Products.PloneTestCase import PloneTestCase
PloneTestCase.setupPloneSite()

class ViewletsTestCase(PloneTestCase.PloneTestCase):
    pass
