// Deprecated; use jQuery(function) (short for 
// jQuery(document).ready(function)) instead.
function addDOMLoadEvent(listener) { jQuery(listener); }
