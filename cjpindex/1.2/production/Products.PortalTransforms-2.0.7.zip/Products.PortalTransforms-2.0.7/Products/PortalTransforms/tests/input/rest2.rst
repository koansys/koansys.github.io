Heading 1
=========

Some text.

Heading 2
---------

Some text, bla ble bli blo blu. Yes, i know this is Stupid_.

.. _Stupid: http://www.example.com

