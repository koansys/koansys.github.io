This packages provides the standard Folder content type for Zope 3. It also
implements the root folder of a Zope application. Folders can also be
converted to sites, which allow one to register components locally.
