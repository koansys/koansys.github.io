Overview
========

plone.portlets provides a generic infrastructure for managing portlets.

Portlets are a bit like viewlets, except they can be manipulated at runtime,
using local components. This package is used by plone.app.portlets to provide
Plone-specific portlets, but should be generic enough to work on other
platforms. It should work in a "pure Zope Toolkit" environment.
