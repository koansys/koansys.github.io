"""
$Id: __init__.py 2886 2004-08-25 03:51:04Z dreamcatcher $
"""
