Introduction
============

This package contains the translation files for Plone Core and the following
non core add-ons:

- LinguaPlone
- plone.app.caching
- plone.app.ldap

This version is not compatible with Plone version inferior to 4.3.

