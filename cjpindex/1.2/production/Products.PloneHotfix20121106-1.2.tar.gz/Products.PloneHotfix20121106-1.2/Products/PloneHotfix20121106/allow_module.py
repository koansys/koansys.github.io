import AccessControl


AccessControl.allow_module.__roles__ = ()
