from App import Undo
Undo.UndoSupport.get_request_var_or_attr__roles__ = ()
