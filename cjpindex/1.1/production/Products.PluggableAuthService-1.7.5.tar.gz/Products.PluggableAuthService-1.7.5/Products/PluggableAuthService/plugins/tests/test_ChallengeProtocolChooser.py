##############################################################################
#
# Copyright (c) 2001 Zope Foundation and Contributors
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this
# distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################
""" Unit tests for ChallengeProtocolChooser

$Id: test_ChallengeProtocolChooser.py 110582 2010-04-07 15:37:24Z tseaver $
"""
import unittest

from Products.PluggableAuthService.tests.conformance \
    import IChallengeProtocolChooser_conformance

class ChallengeProtocolChooser( unittest.TestCase
                                , IChallengeProtocolChooser_conformance 
                              ):


    def _getTargetClass( self ):

        from Products.PluggableAuthService.plugins.ChallengeProtocolChooser \
            import ChallengeProtocolChooser

        return ChallengeProtocolChooser

    def _makeOne( self, id='test', *args, **kw ):

        return self._getTargetClass()( id, *args, **kw )


if __name__ == "__main__":
    unittest.main()
        
def test_suite():
    return unittest.TestSuite((
        unittest.makeSuite( ChallengeProtocolChooser ),
        ))
        
