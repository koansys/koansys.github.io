# Make this directory a python module and import the IRichDocument interface

from richdocument import IRichDocument