
GLOBALS = globals()
