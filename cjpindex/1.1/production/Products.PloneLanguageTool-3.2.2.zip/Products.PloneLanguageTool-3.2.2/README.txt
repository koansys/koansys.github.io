Overview
========

PloneLanguageTool allows you to set the available languages in your Plone
site, select various fallback mechanisms, and control the use of flags
for language selection and translations.

Credits
-------

PloneLanguageTool was built by:

- Jodok Batlogg, "Solution2U":http://solution2u.net

- Simon Eisenmann, "Struktur AG":http://www.strukturag.com

- Geir Baekholt, "Jarn AS":http://www.jarn.com

- Alexander Limi, "Jarn AS":http://www.jarn.com

- Helge Tesdal, "Jarn AS":http://www.jarn.com

- Dorneles Tremea, "Jarn AS":http://www.jarn.com

- Hanno Schlichting, "Jarn AS":http://www.jarn.com

Parts of development sponsored by Learning Lab Denmark, donated by
Plone Solutions.
