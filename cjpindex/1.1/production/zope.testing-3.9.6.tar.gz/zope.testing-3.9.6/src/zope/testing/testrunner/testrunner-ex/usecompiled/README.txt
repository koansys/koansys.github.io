The tests in this subtree are trivial, and used only to test
testrunner's --usecompiled option.
