Overview
========

This distribution contains a full text indexing facility for Zope 2 and more
specifically for Products.ZCatalog.
