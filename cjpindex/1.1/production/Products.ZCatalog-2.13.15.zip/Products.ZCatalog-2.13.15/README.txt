Overview
========

The ZCatalog is Zope 2’s built in search engine. It allows you to categorize
and search all kinds of Zope objects.

It comes with a variety of indexes for different types of data.
