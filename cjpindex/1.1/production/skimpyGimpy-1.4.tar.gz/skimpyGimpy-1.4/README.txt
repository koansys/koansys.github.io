This is the top level directory for the Skimpy Gimpy package.
Release 1.4

Please look to doc/index.html for documentation.
