from plone.registry.registry import Registry
from plone.registry.record import Record
from plone.registry.fieldref import FieldRef