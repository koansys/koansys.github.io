Introduction
============

A portlet that fetches results from a collection.
