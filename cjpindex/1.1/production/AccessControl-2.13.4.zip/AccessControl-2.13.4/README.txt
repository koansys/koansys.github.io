Overview
========

AccessControl provides a general security framework for use in Zope2.
