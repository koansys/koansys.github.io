# This is a backwards compatibility alias. It can be removed once Plone
# doesn't support upgrading from Plone 2.5 anymore.
from Products.CMFPlone.PloneTool import PloneTool
