from Products.ATContentTypes.interfaces.interfaces import IATContentType

class IATLink(IATContentType):
    """AT Link marker interface
    """


