
packageName = 'plone.app.blob'
packageGlobals = globals()

permissions = {
    'Blob': 'plone.app.blob: Add Blob',
    'BlobelFish': 'plone.app.blob: Add BlobelFish',
}

blobScalesAttr = '__blob_scales'
