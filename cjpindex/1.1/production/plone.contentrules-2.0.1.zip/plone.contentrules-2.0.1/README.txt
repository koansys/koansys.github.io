Overview
========

plone.contentrules provides a "pure Zope" implementation of a a rules engine
which allows arbitrary conditions and actions to be combined into rules, and
rules to be executed dependent on events.

You can think of this as somewhat similar to user-assembled mail filtering rules
or something like Apple's Automator. It is used by plone.app.contentrules to
provide such functionality for Plone.
