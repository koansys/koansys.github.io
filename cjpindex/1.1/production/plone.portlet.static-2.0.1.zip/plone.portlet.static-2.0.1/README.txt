Introduction
============

A simple static HTML portlet for Plone 3.
