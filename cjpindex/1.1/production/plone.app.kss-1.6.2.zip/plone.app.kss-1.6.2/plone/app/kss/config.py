from Products.CMFCore import permissions

PROJECTNAME = 'plone.app.kss'
SKINS_DIR = 'skins'

ADD_CONTENT_PERM = permissions.AddPortalContent
VIEW_PERM = permissions.View
MOD_PERM = permissions.ModifyPortalContent

GLOBALS = globals()

