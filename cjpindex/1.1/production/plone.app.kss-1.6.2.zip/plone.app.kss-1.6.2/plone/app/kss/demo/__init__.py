#
# Activate support for old kss.demo version
try:
    import bbb_oldkssdemo
except ImportError:
    pass
