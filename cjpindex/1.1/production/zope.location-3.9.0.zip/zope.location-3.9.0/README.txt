Zope Location
=============

Overview
========

In Zope3, location are special objects that has a structural location.
