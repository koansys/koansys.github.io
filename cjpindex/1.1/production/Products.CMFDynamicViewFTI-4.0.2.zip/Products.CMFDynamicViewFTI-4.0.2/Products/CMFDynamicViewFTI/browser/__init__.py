# -*- coding: utf-8 -*-
"""
Browser subpackage
"""
# $Id: __init__.py 48191 2007-08-29 16:08:43Z glenfant $
