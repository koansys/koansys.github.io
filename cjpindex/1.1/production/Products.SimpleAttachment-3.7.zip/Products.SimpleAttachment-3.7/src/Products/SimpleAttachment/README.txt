SimpleAttachment

  Several Plone products have a need to handle simple attachments: content
  types that do not have a workflow of their own but will reuse the
  permissions on their container. SimpleAttachment implements simple file
  and image attachment types that can serve this need.

  SimpleAttachment is released under the GNU General Public Licence, version 2.
  Please see http://gnu.org for more details.

  Installation

      Install in the usual way, using the QuickInstaller.

  Acknowlegements

      These types were taken from the RichDocument product.
 
