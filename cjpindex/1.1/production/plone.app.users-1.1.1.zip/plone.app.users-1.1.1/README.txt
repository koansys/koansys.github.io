Introduction
============

Package for flexible user registration: allowing site manager to set fields
which appear on the join form.
