Introduction
============

plone.app.contentrules provides Plone-specific conditions and actions, as well
as a user interface for plone.contentrules.

