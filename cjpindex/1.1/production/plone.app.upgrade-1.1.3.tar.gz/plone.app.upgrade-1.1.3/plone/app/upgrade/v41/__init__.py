import alphas
import betas
import final