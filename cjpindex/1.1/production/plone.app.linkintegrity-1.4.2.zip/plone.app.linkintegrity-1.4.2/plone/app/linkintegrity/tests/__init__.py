# tests package
# to run all tests type '.../bin/instance test -s plone.app.linkintegrity'

# disable deprecation warnings
import warnings
warnings.filterwarnings("ignore", ".*", DeprecationWarning)
