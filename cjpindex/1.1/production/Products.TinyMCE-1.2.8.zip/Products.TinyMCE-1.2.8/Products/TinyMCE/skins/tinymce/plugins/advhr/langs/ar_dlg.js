tinyMCE.addI18n('ar.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});