tinyMCE.addI18n('sq.advhr_dlg',{
width:"Gjer\u00EBsia",
size:"Gjat\u00EBsia",
noshade:"Pa hije"
});