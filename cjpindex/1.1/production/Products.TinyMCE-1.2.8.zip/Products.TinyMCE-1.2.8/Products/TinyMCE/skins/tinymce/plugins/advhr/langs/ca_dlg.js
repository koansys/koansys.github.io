tinyMCE.addI18n('ca.advhr_dlg',{
width:"Amplada",
size:"Al\u00E7ada",
noshade:"Sense sombra"
});