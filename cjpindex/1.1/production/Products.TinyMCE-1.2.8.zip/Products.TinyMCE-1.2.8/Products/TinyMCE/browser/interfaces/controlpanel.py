from zope.interface import Interface


class ITinyMCEControlPanelForm(Interface):
    """TinyMCE Control Panel Form"""
