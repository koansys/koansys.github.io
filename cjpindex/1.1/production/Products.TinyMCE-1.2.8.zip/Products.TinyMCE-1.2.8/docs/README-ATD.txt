To enable After the Deadline spelling and grammar checker:
----------------------------------------------------------

- Go to the Plone control panel and click on "TinyMCE Visual Editor"
- Click on 'Toolbar' (middle left)
- Make sure that 'spellchecker' is checked.
- Click on 'Libraries' (top right)
- Under "Spellchecker plugin to use", choose 'After the deadline'
- Under AtD Service URL, choose your ATD server's URL. (The default is their
  public service)
- It's however recommended that you install your own ATD spellchecker service 
  See here for more details:
    http://open.afterthedeadline.com/how-to/get-started/

You should now have AtD enabled and have a spellcheck button in TinyMCE.

