from Products.PloneTestCase.layer import ZCML

PloneOpenId = ZCML
