from zope.interface import Interface

class IValidationCommands(Interface):
    '''commands for AT field validation results'''
