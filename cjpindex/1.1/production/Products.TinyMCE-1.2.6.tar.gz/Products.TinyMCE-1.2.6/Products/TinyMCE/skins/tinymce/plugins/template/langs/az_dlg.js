tinyMCE.addI18n('az.template_dlg',{
title:"\u015Eablonlar",
label:"\u015Eablon",
desc_label:"T\u0259svir",
desc:"\u018Fvv\u0259ld\u0259n m\u00FC\u0259yy\u0259n edil\u0259n \u015Fablon daxil et",
select:"\u015Eablon se\u00E7",
preview:"\u0130lkin bax\u0131\u015F",
warning:"T\u0259hl\u00FCk\u0259: Bir \u015Fablonu bir ba\u015Fqas\u0131yla aktualla\u015Fd\u0131rmaq m\u0259lumat itkisin\u0259 yol a\u00E7a bil\u0259r.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Yanvar,Fevral,Mart,Aprel,May,\u0130yun,\u0130yul,Avqust,Sentaybr,Oktaybr,Noyabr,Dekabr",
months_short:"Yan,Fev,Mar,Ape,May,\u0130yn,\u0130yl,Avq,Sen,Okt,Noy,Dek",
day_long:"Bazar,Bazar ert\u0259si,\u00C7\u0259r\u015F\u0259nb\u0259 ax\u015Fam\u0131,\u00C7\u0259r\u015F\u0259nb\u0259,C\u00FCm\u0259 ax\u015Fam\u0131,C\u00FCm\u0259,\u015E\u0259nb\u0259,Bazar",
day_short:"B,Be,\u00C7a,\u00C7,Ca,C,\u015E,B"
});