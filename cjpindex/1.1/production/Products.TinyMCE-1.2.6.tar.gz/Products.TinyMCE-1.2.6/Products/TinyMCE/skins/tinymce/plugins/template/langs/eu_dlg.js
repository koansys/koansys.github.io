tinyMCE.addI18n('eu.template_dlg',{
title:"Txantiloiak",
label:"Txantiloia",
desc_label:"Deskribapena",
desc:"Txertatu aurredefinitutako txantiloi edukia",
select:"Aukeratu txantiloia",
preview:"Aurreikusi",
warning:"Kontuz: Txantiloi bat beste batekin eguneratzeak data galera sor dezake.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Urtarrila,Otsaila,Martxoa,Apirila,Maiatza,Ekaina,Uztaila,Abuztua,Iraila,Urria,Azaroa,Abendua",
months_short:"Urt,Ots,Mar,Apr,Mai,Eka,Uzt,Abu,Ira,Urr,Aza,Abe",
day_long:"Igandea,Astelehena,Asteartea,Asteazkena,Osteguna,Ostirala,Larunbata,Igandea",
day_short:"Ig,Al,As,Az,Og,Or,Lr,Ig"
});