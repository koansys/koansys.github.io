tinyMCE.addI18n('gl.template_dlg',{
title:"Plantillas",
label:"Plantilla",
desc_label:"Descripci\u00F3n",
desc:"Insertar contido de plantilla predefinida",
select:"Seleccionar plantilla",
preview:"Vista previa",
warning:"Coidado: Actualizar unha plantilla con outra pode causar p\u00E9rdida de datos.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Xaneito,Febreiro,Marzo,Abril,Maio,Xu\u00F1o,Xullo,Agosto,Setembro,Outubro,Novembro,Decembro",
months_short:"Xan,Feb,Mar,Abr,Mai,Xu\u00F1,Xul,Ago,Set,Out,Nov,Dec",
day_long:"Domingo,Luns,Martes,M\u00E9rcores,Xoves,Venres,S\u00E1bado,Domingo",
day_short:"Dom,Lun,Mar,M\u00E9r,Xov,Ver,S\u00E1b,Dom"
});