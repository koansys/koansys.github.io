kss.core
========

Overview
--------

KSS (Kinetic Style Sheets) core framework
