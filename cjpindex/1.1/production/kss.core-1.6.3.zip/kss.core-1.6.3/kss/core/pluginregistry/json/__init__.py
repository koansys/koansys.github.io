'''\
Module init
'''

from utils import getJsonAddonFiles
