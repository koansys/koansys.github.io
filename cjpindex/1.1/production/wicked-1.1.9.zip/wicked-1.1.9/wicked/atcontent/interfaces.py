# @@ deprecate
from wicked.interfaces import IAmWicked, IWickedFilter, IWickedTarget
from wicked.interfaces import IFilterable, IFieldFilter, IAnnotatable




