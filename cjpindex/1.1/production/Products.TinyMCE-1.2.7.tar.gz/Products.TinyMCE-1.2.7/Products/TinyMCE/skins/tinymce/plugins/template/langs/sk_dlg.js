tinyMCE.addI18n('sk.template_dlg',{
title:"\u0160abl\u00F3ny",
label:"\u0160abl\u00F3na",
desc_label:"Popis",
desc:"Vlo\u017Ei\u0165 preddefinovan\u00FD obsah zo \u0161abl\u00F3ny",
select:"Vyber \u0161abl\u00F3nu",
preview:"N\u00E1h\u013Ead",
warning:"Upozornenie: Aktualiz\u00E1cia \u0161abl\u00F3ny inou, sp\u00F4sob\u00ED stratu d\u00E1t.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"Janu\u00E1r,Febru\u00E1r,Marec,Apr\u00EDl,M\u00E1j,J\u00FAn,J\u00FAl,August,September,Okt\u00F3ber,November,December",
months_short:"Jan,Feb,Mar,Apr,M\u00E1j,J\u00FAn,J\u00FAl,Aug,Sep,Okt,Nov,Dec",
day_long:"Nede\u013Ea,Pondelok,Utorok,Streda,\u0160tvrtok,Piatok,Sobota,Nede\u013Ea",
day_short:"Ne,Po,Ut,St,\u0160t,Pi,So,Ne"
});