tinyMCE.addI18n('az.searchreplace_dlg',{
searchnext_desc:"S\u00F6zl\u0259ri axtar",
notfound:"Axtar\u0131\u015F bitdi. S\u0259tr tap\u0131lmad\u0131.",
search_title:"Axtar",
replace_title:"Axtar/D\u0259yi\u015F",
allreplaced:"B\u00FCt\u00FCn qar\u015F\u0131la\u015Fm\u0131\u015F s\u0259trl\u0259r d\u0259yi\u015Fdirildi.",
findwhat:"N\u0259 axtar\u0131ls\u0131n",
replacewith:"N\u0259y\u0259 d\u0259yi\u015Filsin",
direction:"\u0130stiqam\u0259tl\u0259ndirm\u0259",
up:"Yuxar\u0131",
down:"A\u015Fa\u011F\u0131",
mcase:"Registr\u0131 n\u0259z\u0259r\u0259 al",
findnext:"Sonrak\u0131n\u0131 axtar",
replace:"D\u0259yi\u015F",
replaceall:"Ham\u0131s\u0131n\u0131 d\u0259yi\u015F"
});