tinyMCE.addI18n('tr.template_dlg',{
title:"\u015Eablonlar",
label:"\u015Eablon",
desc_label:"A\u00E7\u0131klama",
desc:"\u00D6ntan\u0131ml\u0131 i\u00E7erik \u015Fablonu kullan",
select:"\u015Eablonu se\u00E7",
preview:"\u00D6nizleme",
warning:"Uyar\u0131: Bir \u015Fablonu bir di\u011Feriyle g\u00FCncellemek veri kayb\u0131na yol a\u00E7abilir.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Ocak,\u015Eubat,Mart,Nisan,May\u0131s,Haziran,Temmuz,A\u011Fustos,Eyl\u00FCl,Ekim,Kas\u0131m,Aral\u0131k",
months_short:"Oca,\u015Eub,Mar,Nis,May,Haz,Tem,A\u011Fu,Eyl,Eki,Kas,Ara",
day_long:"Pazar,Pazartesi,Sal\u0131,\u00C7ar\u015Famba,Per\u015Fembe,Cuma,Cumartesi",
day_short:"Paz,Pzt,Sal,\u00C7r\u015F,Per,Cum,Cts"
});