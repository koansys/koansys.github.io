tinyMCE.addI18n('ca.searchreplace_dlg',{
searchnext_desc:"Cerca de nou",
notfound:"S\'ha completat la cerca. No s\'ha trobat la cadena cercada.",
search_title:"Cerca",
replace_title:"Cerca/Reempla\u00E7a",
allreplaced:"S\'han reempla\u00E7at totes les ocurr\u00E8ncies de la cadena cercada.",
findwhat:"Cerca",
replacewith:"Reempla\u00E7a amb",
direction:"Direcci\u00F3",
up:"Amunt",
down:"Avall",
mcase:"Distingeix maj\u00FAscules/min\u00FAscules",
findnext:"Seg\u00FCent",
replace:"Reempla\u00E7a",
replaceall:"Reempla\u00E7a-ho tot"
});