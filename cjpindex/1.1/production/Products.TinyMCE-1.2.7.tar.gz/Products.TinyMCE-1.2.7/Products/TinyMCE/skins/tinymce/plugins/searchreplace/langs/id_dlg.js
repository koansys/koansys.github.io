tinyMCE.addI18n('id.searchreplace_dlg',{
searchnext_desc:"Cari Lagi",
notfound:"Pencarian selesai. Hasil tidak ditemukan.",
search_title:"Cari",
replace_title:"Cari/Ganti",
allreplaced:"Seluruh kata dari string pencarian telah digantikan",
findwhat:"Cari apa...",
replacewith:"Ganti dengan...",
direction:"Arah",
up:"Atas",
down:"Bawah",
mcase:"Match case",
findnext:"Cari selanjutnya",
replace:"Ganti",
replaceall:"Ganti semua"
});