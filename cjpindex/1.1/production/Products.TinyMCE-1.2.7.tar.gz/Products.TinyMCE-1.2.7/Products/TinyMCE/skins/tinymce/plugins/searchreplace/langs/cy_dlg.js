tinyMCE.addI18n('cy.searchreplace_dlg',{
searchnext_desc:"Canfod eto",
notfound:"Mae'r chwiliad wedi cwblhau. Methu canfod y llinyn chwiliad.",
search_title:"Canfod",
replace_title:"Canfod/Amnewid",
allreplaced:"Amnewidwyd pob digwyddiad o'r llinyn chwiliad.",
findwhat:"Canfod beth",
replacewith:"Adnewid gyda",
direction:"Cyfeiriad",
up:"I fyny",
down:"I lawr",
mcase:"Cydweddu priflythrennedd",
findnext:"Canfod nesaf",
replace:"Amnewid",
replaceall:"Amnewid pob un"
});