TinyMCE
=======

Adds support for TinyMCE, a platform independent web based Javascript HTML
WYSIWYG editor, to Plone.

Feedback
--------

Please send any changes, improvements, or suggestions regarding this Plone
product to `Four Digits <mailto:info@fourdigits.nl>`_

Requirements
------------

TinyMCE is tested on Plone 4, please submit any compatibility issues
you may encounter.
