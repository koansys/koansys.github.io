"""\
Unit test package for CMFPlone

To run all tests type 'python runalltests.py'
"""
GLOBALS = globals()
