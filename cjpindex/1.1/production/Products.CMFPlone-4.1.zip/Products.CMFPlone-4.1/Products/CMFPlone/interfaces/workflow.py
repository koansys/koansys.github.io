from zope.interface.common.sequence import IReadSequence


class IWorkflowChain(IReadSequence):
    """ an interface denoting the cmf workflow name sequence
    """
