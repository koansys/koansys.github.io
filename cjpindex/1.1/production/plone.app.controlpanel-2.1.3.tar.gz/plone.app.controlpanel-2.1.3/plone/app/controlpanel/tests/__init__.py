# Other packages may find this useful

from plone.app.controlpanel.tests.cptc import ControlPanelTestCase