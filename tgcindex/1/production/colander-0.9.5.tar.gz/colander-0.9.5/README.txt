Colander
========

An extensible package which can be used to:

- deserialize and validate a data structure composed of strings,
  mappings, and lists.

- serialize an arbitrary data structure to a data structure composed
  of strings, mappings, and lists.

Please see http://docs.pylonsproject.org/projects/colander/dev/
for further documentation.
