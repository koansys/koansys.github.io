==========
Octomotron
==========

Octomotron is a tool for rapidly deploying multiple evaluation instances of a
webapp from branches stored in git.  Octomotron sets up intances using
zc.buildout and mr.developer.  Developers using Octomotron will need to provide
a buildout configuration as well as a plugin written in Python that Octomotron
can call into for logic pertaining to your application.
