

class UserError(Exception):
    pass
