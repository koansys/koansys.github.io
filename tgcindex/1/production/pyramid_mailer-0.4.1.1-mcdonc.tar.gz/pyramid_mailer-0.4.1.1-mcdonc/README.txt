pyramid_mailer is a package for sending email from your Pyramid application.

See the documentation at
https://docs.pylonsproject.org/projects/pyramid_mailer/dev/ for more info.

pyramid_mailer uses code from the Lamson Project (http://lamsonproject.org/)
with permission.  See the LICENSE.txt file for more information.
