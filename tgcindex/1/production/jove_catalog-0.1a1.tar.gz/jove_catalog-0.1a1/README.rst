============
jove_catalog
============

A local service for Jove which provides search capabilities via
repoze.catalog.
