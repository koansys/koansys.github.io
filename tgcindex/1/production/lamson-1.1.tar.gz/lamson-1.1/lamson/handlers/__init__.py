"""
Lamson comes with a few useful handlers that you can add to your lamson.routing
configuration.  Most of them are implemented as stateless handlers, but some
will require you to read the documentation and configure before you can use
them.
"""
