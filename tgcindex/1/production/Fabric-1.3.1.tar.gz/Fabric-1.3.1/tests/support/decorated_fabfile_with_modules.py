from fabric.decorators import task
import module_fabtasks as tasks

@task
def foo():
    pass

def bar():
    pass
