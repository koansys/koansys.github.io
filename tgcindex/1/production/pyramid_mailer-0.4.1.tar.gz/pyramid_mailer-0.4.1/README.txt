pyramid_mailer is a package for sending email from your Pyramid application.


