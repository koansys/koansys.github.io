
def evolve(home):
    home['content']['one_six'] = 'evolved'
