
def evolve(home):
    home['content']['two_five'] = 'evolved'
