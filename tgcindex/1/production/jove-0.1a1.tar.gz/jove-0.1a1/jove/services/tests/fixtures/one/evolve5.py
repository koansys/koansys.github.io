
def evolve(home):
    home['content']['one_five'] = 'evolved'
