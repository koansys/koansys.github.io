
def evolve(home):
    home['content']['two_four'] = 'evolved'
