.. Jove documentation master file, created by
   sphinx-quickstart on Tue Jul 19 09:16:21 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Jove Application Server
=======================

`Jove` is an application server and site manager for `Pyramid` web
applications that use `ZODB`.

Contents:

.. toctree::
   :maxdepth: 1

   application.rst
   site.rst
   settings.rst
   service.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

